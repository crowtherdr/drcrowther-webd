var MORSE_CODE = { '-.-.--': '!',
'.-..-.': '"',
'...-..-': '$',
'.-...': '&',
'.----.': '\'',
'-.--.': '(',
'-.--.-': ')',
'.-.-.': '+',
'--..--': ',',
'-....-': '-',
'.-.-.-': '.',
'-..-.': '/',
'-----': '0',
'.----': '1',
'..---': '2',
'...--': '3',
'....-': '4',
'.....': '5',
'-....': '6',
'--...': '7',
'---..': '8',
'----.': '9',
'---...': ':',
'-.-.-.': ';',
'-...-': '=',
'..--..': '?',
'.--.-.': '@',
'.-': 'A',
'-...': 'B',
'-.-.': 'C',
'-..': 'D',
'.': 'E',
'..-.': 'F',
'--.': 'G',
'....': 'H',
'..': 'I',
'.---': 'J',
'-.-': 'K',
'.-..': 'L',
'--': 'M',
'-.': 'N',
'---': 'O',
'.--.': 'P',
'--.-': 'Q',
'.-.': 'R',
'...': 'S',
'-': 'T',
'..-': 'U',
'...-': 'V',
'.--': 'W',
'-..-': 'X',
'-.--': 'Y',
'--..': 'Z',
'..--.-': '_',
'...---...': 'SOS' };

decodeMorse = function(morseCode){
  var morseCode = morseCode || "";
  var morseCodeWordArray = morseCode.split("   ");
  var decodedString = "";

  morseCodeWordArray.map(function(arrayWord) {
    arrayWord = arrayWord.split(" ");
    arrayWord.map(function(arrayWordLetter) {
      if (MORSE_CODE[arrayWordLetter]) {
        decodedString += MORSE_CODE[arrayWordLetter];
      }
    });

    decodedString += " ";
  });

  console.log('decodedString ' , "|" + decodedString.trim() + "|");
  return decodedString.trim();
}
decodeMorse('.... . -.--   .--- ..- -.. .'); // 'HEY JUDE'
