//top voted: authors: jkarttunen & Meow
function openOrSenior(data){
  function determineMembership(member){
    return (member[0] >= 55 && member[1] > 7) ? 'Senior' : 'Open';
  }
  return data.map(determineMembership);
}

// Mine
// function openOrSenior(data){
//   var i = 0;
//   var membershipStatus;
//   var statusArray = [];

//   while(i < data.length) {

//     membershipStatus = (data[i][0] >= 55 && data[i][1] > 7) ? "Senior": "Open";
//     statusArray.push(membershipStatus);
//     i++;
//   }

//   return statusArray;
// }

// console.log(openOrSenior([[18, 20],[45, 2],[61, 12],[37, 6],[21, 21],[78, 9]]));

openOrSenior([[18, 20],[45, 2],[61, 12],[37, 6],[21, 21],[78, 9]])