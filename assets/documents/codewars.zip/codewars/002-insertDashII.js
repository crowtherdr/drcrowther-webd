// This is a follow up from my kata Insert Dashes.
// Write a function insertDashII(num) that will insert dashes ('-') between each two odd numbers and asterisk ('*') between each even numbers in num
// For example:
// insertDashII(454793) --> 4547-9-3
// insertDashII(1012356895) --> 10123-56*89-5

// Zero shouldn't be considered even or odd.

function insertDashII(num) {
  var numberString = "" + num;
  var i = 0;

  while (i < (numberString.length - 1)) {
    if (parseInt(numberString[i], 10) !== 0) {
      if (parseInt(numberString[i], 10)%2 === 1 && parseInt(numberString[i+1], 10)%2 === 1) {
        numberString = numberString.substring(0, i+1) + "-" + numberString.substring(i+1, numberString.length);
        i++;
      }
      else if (parseInt(numberString[i], 10)%2 === 0 && (parseInt(numberString[i+1], 10) !== 0 && parseInt(numberString[i+1], 10)%2 === 0)) {
        numberString = numberString.substring(0, i+1) + "*" + numberString.substring(i+1, numberString.length);
        i++;
      }
    }
    i++;
  }

  return numberString;
}

console.log(insertDashII(454793));
console.log(insertDashII(1012356895));
console.log(insertDashII(40546793));
