function descendingValueToSizeRatioCompare(a,b) {
  if (a.item[1]/a.item[0] > b.item[1]/b.item[0])
    return -1;
  else if (a.item[1]/a.item[0] < b.item[1]/b.item[0])
    return 1;
  else
    return 0;
}

function ascendingIdCompare(a,b) {
  if (a.id < b.id)
    return -1;
  else if (a.id > b.id)
    return 1;
  else
    return 0;
}

var knapsack=function(capacity,items){
// console.log('capacity ' , capacity);
// console.log('items ' , items);
  var capacity = capacity || 0;
  var items = items || 0;
  var tempItemArray = [];
  var tempItemsToTake = [];
  var itemsToTake = [];

  for (var i = 0; i < items.length; i++) {
    tempItemArray.push({ id: i, item: items[i]});
  }
// console.log('tempItemArray ' , tempItemArray);


  tempItemArray.sort(descendingValueToSizeRatioCompare);

// console.log('items-sorted: ' , tempItemArray);
  var i = 0;
  while (i < tempItemArray.length && capacity > 0) {
// console.log('i ' , i);
// console.log('tempItemArray[i] ' , tempItemArray[i].item[0]);
    // if (capacity / tempItemArray[i].item[0] >= 1) {
    tempItemsToTake.push({ id: tempItemArray[i].id, numberOfItem: Math.floor(capacity / tempItemArray[i].item[0])});
// console.log('(tempItemArray[i].item[0] * tempItemsToTake[i]) ' , (tempItemArray[i].item[0] * tempItemsToTake[i].numberOfItem));
    capacity = capacity - (tempItemArray[i].item[0] * tempItemsToTake[i].numberOfItem);
// console.log('capacity ' , capacity);
    // }
    i++;
  }

  tempItemsToTake.sort(ascendingIdCompare);

  for (var i = 0; i < tempItemsToTake.length; i++) {
    itemsToTake.push(tempItemsToTake[i].numberOfItem);
  }

// console.log('new-capacity ' , capacity);
console.log('itemsToTake ' , itemsToTake);
// console.log("************************************");
  return itemsToTake;
}


// One items
knapsack(100, [[1, 1]]); // Expected [100]
knapsack(100, [[100, 1]]); // Expected [1]

// Two items
knapsack(100, [[1, 1],[3, 4]]); // Expected: [1, 33]
knapsack(100, [[60, 80],[50, 50]]); // Expected: [1, 0]

// Three items
knapsack(100, [[10, 10],[30, 40],[56, 78]]); // Expected: [1, 1, 1]
knapsack(100, [[11.2,  7.4],[25.6, 17.8],[51.0, 41.2],[23.9, 15.6],[27.8, 19.0]]); // Expected: [2, 1, 1, 0, 0]

// .66 2
// .69 1
// .80 1
// .65 0
// .68 0

// 2 1 4 0 3