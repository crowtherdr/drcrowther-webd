function tribonacci(signature,n){
  var signatureLength = signature.length;

  if (n > signatureLength) {
    var index = 0;

    while (signature.length < n) {
      signature.push(signature[index] + signature[index + 1] + signature[index + 2]);

      index++;
    }
  }
  else {
    signature = signature.slice(0,n);
  }

console.log('signature ' , signature);
  return signature;
}

tribonacci([1,1,1],10); //[1,1,1,3,5,9,17,31,57,105]
tribonacci([0,0,1],10); //[0,0,1,1,2,4,7,13,24,44]
tribonacci([0,1,1],10); //[0,1,1,2,4,7,13,24,44,81]
tribonacci([1,1,1],0); //[]
tribonacci([1,1,1],1); //[1]
