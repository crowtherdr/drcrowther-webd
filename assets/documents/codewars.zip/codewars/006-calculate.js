function calculate(argsSet1) {
  var grandTotal = 0;

  function addEm(argumentSet) {
    var setTotal = 0;
    var argumentsSetIndex = 0;
    while (argumentsSetIndex < argumentSet.length) {
      setTotal = setTotal + argumentSet[argumentsSetIndex];
      argumentsSetIndex++;
    }
    return setTotal;
  }

  grandTotal = addEm(arguments);

  return function(argsSet2){
    grandTotal = grandTotal + addEm(arguments);
console.log('grandTotal ' , grandTotal);
    return grandTotal;
  };
}


// You are writing a function that takes two sets of arguments of arbitrary length. The return value will be the sum of the values of all of the arguments.

// The function should contain at least 1 argument per set.

calculate(1)(1) // should return 2
calculate(1,1)(1) // should return 3
calculate(1,1)(1,-1) // should return 2
calculate(2,4)(3,7,1) // should return 17

// Test.assertEquals(calculate(1)(1), 2);
// Test.assertEquals(calculate(1,1)(1) , 3);
// Test.assertEquals(calculate(1,1)(1,-1), 2);
// Test.assertEquals(calculate(2,4)(3,7,1), 17);
