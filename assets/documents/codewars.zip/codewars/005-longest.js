// function longest(s1, s2) {
//   var combinedArray = [];

//   var compareCombine = function(arrayItem, index, s1Array) {
//     if (combinedArray.indexOf(arrayItem) === -1) {
//       combinedArray.push(arrayItem);
//     }
//   }

//   var s1Array = s1.split("");
//   var s2Array = s2.split("");
//   // console.log('s1Array ' , s1Array);
//   // console.log('s2Array ' , s2Array);

//   s1Array.forEach(compareCombine);
//   s2Array.forEach(compareCombine);

//   combinedArray.sort();
//   console.log('longest: ' , combinedArray.join(""));

//   return combinedArray.join("");
// }


// By nathanbenn
function longest(s1, s2) {
  s3 = s1 + s2;
  s4 = s3.split("");
  s4 = s4.sort().filter(function(element, index, array){
    return element !== array[index - 1];
  });
  return s4.join("");
  console.log('s4.join("") ' , s4.join(""));
}

longest("aretheyhere", "yestheyarehere"); // aehrsty
longest("loopingisfunbutdangerous", "lessdangerousthancoding"); // abcdefghilnoprstu
longest("inmanylanguages", "theresapairoffunctions"); // acefghilmnoprstuy

// a = "xyaabbbccccdefww"
// b = "xxxxyyyyabklmopq"
// longest(a, b) // -> "abcdefklmopqwxy"

// a = "abcdefghijklmnopqrstuvwxyz"
// longest(a, a) -> "abcdefghijklmnopqrstuvwxyz"