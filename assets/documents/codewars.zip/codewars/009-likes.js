function likes(names) {
  var names = names || [];
  var likesString;
  var namesLength = names.length;
  var templates = [
    "no one likes this",
    "$0 likes this",
    "$0 and $1 like this",
    "$0, $1 and $2 like this",
    "$0, $1 and " + (namesLength - 2) + " others like this"
  ];

  function replacer(templateString) {
    return templateString.replace(/\$([0,1,2])/g, function(match, $0) {
      return names[$0];
    });
  }

  switch(namesLength) {
    case 0:
      likesString = templates[namesLength];
      break;
    case 1:
      likesString = replacer(templates[namesLength]);
      break;
    case 2:
      likesString = replacer(templates[namesLength]);
      break;
    case 3:
      likesString = replacer(templates[namesLength]);
      break;
    default:
      likesString = replacer(templates[4]);
  }
console.log("likesString: ", likesString);
  return likesString;
}

likes([]); //no one likes this'
likes(['Peter']); //Peter likes this'
likes(['Jacob', 'Alex']); //Jacob and Alex like this'
likes(['Max', 'John', 'Mark']); //Max, John and Mark like this'
likes(['Alex', 'Jacob', 'Mark', 'Max']); //Alex, Jacob and 2 others like this'