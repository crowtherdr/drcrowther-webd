// buildOneTwoThree()
// Uses push()

buildOneTwoThree = function(numNodes) {
  return numNodes;
}