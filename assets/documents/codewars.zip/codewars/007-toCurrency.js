function toCurrency(price){
  price = (price.toString()).replace(/(\d)(?=(\d{3})+$)/g, '$1,');
console.log("price", price);
  return price;
}

price1 = 123456;
price2 = 1234;
price3 = 123;
price4 = 123456789012;
toCurrency(price1); //"123,456"
toCurrency(price2); //"1,234"
toCurrency(price3); //"123"
toCurrency(price4); //"123,456,789,012"