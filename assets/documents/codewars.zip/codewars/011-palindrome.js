function palindrome(string) {
  var string = string || "";
  string = string.toLowerCase().replace(/[^a-z]/g,"");
  var reversedCompareString = "";
  var stringIndex = 0;

  stringIndex =string.length - 1;
  for (; stringIndex >= 0; stringIndex--) {
    reversedCompareString += string[stringIndex];
  }

// console.log('(string === reversedCompareString) ' , (string === reversedCompareString));
  return (string === reversedCompareString);
}

palindrome("Amore, Roma"); // true
palindrome("A man, a plan, a canal: Panama"); // true
palindrome("No 'x' in 'Nixon'"); // true
palindrome("Abba Zabba, you're my only friend"); // false
