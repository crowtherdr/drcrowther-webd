function onLine(points) {
  var areOnLine = true;

  if (points.length > 1) {
    var yCoord = points[0][1];
    var xCoord = points[0][0];
    var slope = (yCoord - points[1][1]) / (xCoord - points[1][0]);

    for(x = 1; x < points.length; x++) {
      if (points[x][0] !== xCoord && points[x][1] !== yCoord && (points[x][1] - yCoord !== slope * (points[x][0] - xCoord))) {
        areOnLine = false;
      }
      xCoord = points[x][0];
      yCoord = points[x][1];
    }
  }

console.log("points: ", points);
console.log('areOnLine ' , areOnLine);
  return areOnLine;
}

onLine([[1,2], [7, 4], [22, 9]]);
onLine([[1,2], [-3, -14], [22, 9]]);
onLine([[1, 2], [1, 4], [1, 7]]);
onLine([[1, 1], [0, 0], [1, -1]]);
onLine([]);
onLine([[]]);
