function undoRedo(object) {
  var helperObject = {};
  helperObject.trash = [];
  helperObject.undoHistory = [];
  var lastActionWasUndo = false;

  var emptyTrash = function() {
    helperObject.trash = [];
    helperObject.undoHistory = [];
  };

  var updateTrashWithCreateOrSet = function(myKey) {
    if (!object[myKey]) {
      helperObject.trash.push({ action: "create", key: myKey, value: "" });
    }
    else {
      helperObject.trash.push({ action: "set", key: myKey, value: object[myKey] });
    }
  };

  var addToUndoHistory = function(undoInfoObject) {
    switch(undoInfoObject.action) {
      case "create":
        helperObject.undoHistory.push({ action: "create", key: undoInfoObject.key, value: object[undoInfoObject.key] });
        delete object[undoInfoObject.key];
        break;

      case "set":
        helperObject.undoHistory.push({ action: "set", key: undoInfoObject.key, value: object[undoInfoObject.key] });
        object[undoInfoObject.key] = undoInfoObject.value;
        break;

      case "del":
        helperObject.undoHistory.push({ action: "del", key: undoInfoObject.key, value: object[undoInfoObject.key] });
        object[undoInfoObject.key] = undoInfoObject.value;
        break;

      default:
        throw("Invalid action.");
    }
  };

  var addToTrash = function(redoInfoObject) {
    switch(redoInfoObject.action) {
      case "create":
        helperObject.trash.push({ action: "create", key: redoInfoObject.key, value: object[redoInfoObject.key] });
        object[redoInfoObject.key] = redoInfoObject.value;
        break;

      case "set":
        helperObject.trash.push({ action: "set", key: redoInfoObject.key, value: object[redoInfoObject.key] });
        object[redoInfoObject.key] = redoInfoObject.value;
        break;

      case "del":
        helperObject.trash.push({ action: "del", key: redoInfoObject.key, value: object[redoInfoObject.key] });
        delete object[redoInfoObject.key];
        break;

      default:
        throw("Invalid action.");
    }
  };

  return {
    set: function(key, value) {
      if (lastActionWasUndo) { // Clear any remaining history
        emptyTrash();
        lastActionWasUndo = false;
      }

      updateTrashWithCreateOrSet(key);

      object[key] = value;
    },

    get: function(key) {
      return object[key];
    },

    del: function(key) {
      if (lastActionWasUndo) { // Clear any remaining history
        emptyTrash();
        lastActionWasUndo = false;
      }

      if (object[key]) {
        helperObject.trash.push({ action: "del", key: key, value: object[key] });
      }

      delete object[key];
    },

    undo: function() {
      lastActionWasUndo = true;

      if (helperObject.trash && helperObject.trash.length > 0) {
        var undoInfoObject = helperObject.trash[helperObject.trash.length - 1];
        helperObject.trash.pop();

        addToUndoHistory(undoInfoObject);
      }
      else {
        throw(false); // There is nothing to undo
      }
    },
    redo: function() {
      if (lastActionWasUndo) {
        if (helperObject.undoHistory && helperObject.undoHistory.length > 0) {
          var redoInfoObject = helperObject.undoHistory[helperObject.undoHistory.length - 1];
          helperObject.undoHistory.pop();

          addToTrash(redoInfoObject);
        }
        else {
          throw(false);
        }
      }
      else {
        throw(false); // There is nothing to redo
      }
    }
  };
}

var obj = {
  x: 1,
  y: 2
};

var unRe = undoRedo(obj);

// console.log("get x, x is 1", unRe.get('x'));

// unRe.set('x', 3);
// console.log("set x, now x is 3 ", unRe.get('x'));

// unRe.set('x', 5);
// console.log("set x, now x is 5 ", unRe.get('x'));

// unRe.undo();
// console.log("undo set x, now x is 3 again", unRe.get('x'));


// unRe.set('y', 2);
// console.log("create y, now y is 2 ", unRe.get('y'));


// START: simple undo
  unRe.set('y', 10);
  console.log(unRe.get('y'),'y is 10');
  unRe.undo();
  console.log(unRe.get('y'), 'y is 2 again after undo');
  try {
    unRe.undo();
    console.log('It should have thrown an exception');

  } catch (e) {
    console.log(unRe.get('y'), "y is still 2 after a failed undo");
  }

// END: simple undo



// START: simple redo
// unRe.set('y', 10);
// console.log("set y, now y is 10 (was 2) ", unRe.get('y'));

// unRe.undo();
// console.log("undo y, now y is 2 again", unRe.get('y'));

// unRe.redo();
// console.log("redo set y, now y is 10 again ", unRe.get('y'));

// console.log("Try redo again");
// try {
//   unRe.redo();
//   // console.log("It should have thrown an exception");

// } catch (e) {
//   console.log("y should be 10", unRe.get('y'));
// }
// END: simple redo


// START: undo/redo
  // unRe.set('y', 10);
  // unRe.set('y', 100);
  // unRe.set('x', 150);
  // unRe.set('x', 50);
  // console.log("y should be 100", unRe.get('y'));
  // console.log("x should be 50", unRe.get('x'));

  // unRe.undo();
  // console.log("x should be 150", unRe.get('x'));
  // console.log("y should be 100", unRe.get('y'));
  // unRe.redo();
  // console.log("x should be 50", unRe.get('x'));
  // console.log("y should be 100", unRe.get('y'));
  // unRe.undo();
  // unRe.undo();
  // console.log("x should be 1", unRe.get('x'));
  // console.log("y should be 100", unRe.get('y'));
  // unRe.undo();
  // unRe.undo();
  // console.log("y should be 2", unRe.get('y'));
  // console.log("x should be 1", unRe.get('x'));
  // try {
  //   unRe.undo();
  //   console.log("It should have thrown an exception");

  // } catch (e) {
  //   console.log("y should be 2", unRe.get('y'));
  // }
  // unRe.redo();
  // unRe.redo();
  // unRe.redo();
  // unRe.redo();
  // console.log("y should be 100", unRe.get('y'));
  // console.log("y should be 50", unRe.get('x'));
  // try {
  //   unRe.redo();
  //   console.log("It should have thrown an exception");

  // } catch (e) {
  //   console.log("y should be 100", unRe.get('y'));
  // }
// END: undo/redo



// START: delete key
// var obj = {
//   x: 1,
//   y: 2
// };

// var unRe = undoRedo(obj);
// unRe.del('x');
// console.log(unRe.get('x'), 'The x key should not exist');
// console.log(!obj.hasOwnProperty('x'), 'The x key should be deleted');

// unRe.undo();
// console.log(unRe.get('x'), 'x should be 1');

// unRe.redo();
// console.log(unRe.get('x'), undefined, 'The x key should not exist');
// console.log(!obj.hasOwnProperty('x'), 'The x key should be deleted');
// END: delete key





// unRe.set('z', 10);
// console.log("set z, now z is 10 ", unRe.get('z'));

// unRe.set('z', 2);
// console.log("set z, now z is 2 ", unRe.get('z'));

// unRe.undo();
// console.log("undo set z, now z is 10 ", unRe.get('z'));

// unRe.undo();
// console.log("undo set z, now z is undefined ", unRe.get('z'));

// unRe.redo();
// console.log("redo set z, now z is 10 ", unRe.get('z'));

// unRe.undo();
// nothing to undo



// unRe.redo();

// unRe.undo();
// console.log("undo set x, now x is 1 again", unRe.get('x'));
// unRe.redo();
// console.log("redo set x, should be 3 again", unRe.get('x'));

// console.log("__________________________");
// unRe.set('z', 2);
// console.log("set z", unRe.get('z'));
// unRe.redo();

// unRe.del('z');
// console.log("del z", unRe.get('z'));
// unRe.redo();

// unRe.undo();
// console.log("undo del z", unRe.get('z'));
// unRe.redo();
// console.log("redo del z, should be undefined", unRe.get('z'));

// unRe.redo();



// Test.describe('tests', function() {

//   Test.it('get/set tests', function() {
//     var obj = {
//       x: 1,
//       y: 2
//     };

//     var unRe = undoRedo(obj);

//     Test.assertEquals(unRe.get('x'), 1, 'The get method returns the value of a key');
//     unRe.set('x', 3);
//     Test.assertEquals(unRe.get('x'), 3, 'The set method change the value of a key');
//    });

//    Test.it('simple undo', function() {
//      var obj = {
//         x: 1,
//         y: 2
//       };

//       var unRe = undoRedo(obj);
//       unRe.set('y', 10);
//       Test.assertEquals(unRe.get('y'), 10, 'The get method returns the value of a key');
//       unRe.undo();
//       Test.assertEquals(unRe.get('y'), 2, 'The undo method restores the previous state');
//       try {
//         unRe.undo();
//         Test.expect(false, 'It should have thrown an exception');

//       } catch (e) {
//         Test.assertEquals(unRe.get('y'), 2);
//       }

//    });

//    Test.it('simple redo', function() {
//      var obj = {
//         x: 1,
//         y: 2
//       };

//       var unRe = undoRedo(obj);
//       unRe.set('y', 10);
//       Test.assertEquals(unRe.get('y'), 10, 'The get method returns the value of a key');
//       unRe.undo();
//       Test.assertEquals(unRe.get('y'), 2, 'The undo method restores the previous state');
//       unRe.redo();
//       Test.assertEquals(unRe.get('y'), 10, 'The undo method restores the previous state');
//       try {
//         unRe.redo();
//         Test.expect(false, 'It should have thrown an exception');

//       } catch (e) {
//         Test.assertEquals(unRe.get('y'), 10);
//       }

//    });

//   Test.it('undo/redo', function() {
//      var obj = {
//         x: 1,
//         y: 2
//       };

//       var unRe = undoRedo(obj);
//       unRe.set('y', 10);
//       unRe.set('y', 100);
//       unRe.set('x', 150);
//       unRe.set('x', 50);
//       Test.assertEquals(unRe.get('y'), 100, 'The get method returns the value of a key');
//       Test.assertEquals(unRe.get('x'), 50, 'The get method returns the value of a key');
//       unRe.undo();
//       Test.assertEquals(unRe.get('x'), 150, 'The undo method restores the previous state');
//       Test.assertEquals(unRe.get('y'), 100, 'The y key stays the same');
//       unRe.redo();
//       Test.assertEquals(unRe.get('x'), 50, 'Undo the x value');
//       Test.assertEquals(unRe.get('y'), 100, 'The y key stays the same');
//       unRe.undo();
//       unRe.undo();
//       Test.assertEquals(unRe.get('x'), 1, 'Undo the x value');
//       Test.assertEquals(unRe.get('y'), 100, 'The y key stays the same');
//       unRe.undo();
//       unRe.undo();
//       Test.assertEquals(unRe.get('y'), 2, 'Undo the y value');
//       Test.assertEquals(unRe.get('x'), 1, 'The x key stays the same');
//       try {
//         unRe.undo();
//         Test.expect(false, 'It should have thrown an exception');

//       } catch (e) {
//         Test.assertEquals(unRe.get('y'), 2, 'There is nothing to undo');
//       }
//       unRe.redo();
//       unRe.redo();
//       unRe.redo();
//       unRe.redo();
//       Test.assertEquals(unRe.get('y'), 100, 'y key redo state');
//       Test.assertEquals(unRe.get('x'), 50, 'y key redo state');
//       try {
//         unRe.redo();
//         Test.expect(false, 'It should have thrown an exception');

//       } catch (e) {
//         Test.assertEquals(unRe.get('y'), 100, 'There is nothing to redo');
//       }

//    });

//    Test.it('new key', function() {
//      var obj = {
//         x: 1,
//         y: 2
//       };

//       var unRe = undoRedo(obj);
//       unRe.set('z', 10);
//       Test.assertEquals(unRe.get('z'), 10, 'A new key has been added');
//       unRe.undo();
//       Test.assertEquals(unRe.get('z'), undefined, 'The z key should not exist');
//       unRe.redo();
//       Test.assertEquals(unRe.get('z'), 10, 'A new key has been added');
//    });


//    Test.it('delete key', function() {
//      var obj = {
//         x: 1,
//         y: 2
//       };

//       var unRe = undoRedo(obj);
//       unRe.del('x');
//       Test.assertEquals(unRe.get('x'), undefined, 'The x key should not exist');
//       Test.expect(!obj.hasOwnProperty('x'), 'The x key should be deleted');
//       unRe.undo();
//       Test.assertEquals(unRe.get('x'), 1, 'A new key has been added');
//       unRe.redo();
//       Test.assertEquals(unRe.get('x'), undefined, 'The x key should not exist');
//       Test.expect(!obj.hasOwnProperty('x'), 'The x key should be deleted');
//    });


//  });
//