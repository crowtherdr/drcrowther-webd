function autocorrect(input){
  var newWordOrPhrase = "your sister";

  // What I submitted
  // input = input.replace(/(\b)you*(\b)|(\b)u(\b)/gi, "$1" + newWordOrPhrase + "$2");
  input = input.replace(/\b(you*|u)\b/gi, newWordOrPhrase);

console.log('input: ' , input);
  return input;
}

autocorrect("u"); // u
autocorrect("you"); // you
autocorrect("YOU"); // YOU
autocorrect("youuuuuuuuuuu"); // youuuuuuuuuuu
autocorrect("youtube"); // youtube
autocorrect("bayou"); // bayou
autocorrect("what about you and your car"); // what about you and your car
autocorrect("how about ice cream for the bayou and you"); // how about ice cream for the bayou and you
autocorrect("this is for u and the neighbor"); // this is for u and the neighbor
autocorrect("youuu and me and the mountains"); // youuu and me and the mountains
autocorrect("hot chocolate for u and my friend"); // hot chocolate for u and my friend


// Test.assertEquals(autocorrect("u"), "your sister");
// Test.assertEquals(autocorrect("you"), "your sister");
// Test.assertEquals(autocorrect("YOU"), "your sister");
// Test.assertEquals(autocorrect("youuuuuuuuuuu"), "your sister");
// Test.assertEquals(autocorrect("youtube"), "youtube");
// Test.assertEquals(autocorrect("bayou"), "bayou");
// Test.assertEquals(autocorrect("what about you and your car"), "what about your sister and your car");
// Test.assertEquals(autocorrect("how about ice cream for the bayou and you"), "how about ice cream for the bayou and your sister");
// Test.assertEquals(autocorrect("this is for u and the neighbor"), "this is for your sister and the neighbor");
// Test.assertEquals(autocorrect("youuu and me and the mountains"), "your sister and me and the mountains");
// Test.assertEquals(autocorrect("hot chocolate for u and my friend"), "hot chocolate for your sister and my friend");
