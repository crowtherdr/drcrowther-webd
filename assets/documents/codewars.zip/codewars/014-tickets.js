function tickets(peopleInLine){
  var twentyfives = 0;
  var fifties = 0;
  var onehundreds = 0;
  var amountChangeLeft = 0;
  var tempFifties = 0;
  var tempTwentyFives = 0;
  var canHelpEveryone = "YES";
  var peopleInLineIndex = 0;

  while (peopleInLineIndex < peopleInLine.length && canHelpEveryone === "YES") {
    switch(peopleInLine[peopleInLineIndex]) {
      case 25:
        twentyfives++;
        break;
      case 50:
        if (twentyfives > 0) {
          twentyfives--;
        }
        else {
          canHelpEveryone = "NO";
        }
        fifties++;
        break;
      case 100:
        amountChangeLeft = 75;
        tempTwentyFives = twentyfives;
        tempFifties = fifties;

        while (amountChangeLeft > 0 && canHelpEveryone === "YES") {
          if (tempFifties > 0) {
            amountChangeLeft -= 50;
            tempFifties--;
          } else if (tempTwentyFives > 0) {
            amountChangeLeft -= 25;
            tempTwentyFives--;
          } else {
            canHelpEveryone = "NO";
          }
        }

        if (canHelpEveryone === "YES") {
          twentyfives = tempTwentyFives;
          fifties = tempFifties;
          onehundreds++;
        }

        break;
      default:
        canHelpEveryone = "NO"; //invalid amount
    }
    peopleInLineIndex++;
  }

// console.log('twentyfives ' , twentyfives);
// console.log('fifties ' , fifties);
// console.log('onehundreds ' , onehundreds);
// console.log('canHelpEveryone ' , canHelpEveryone);
  return canHelpEveryone;
}

tickets([25, 25, 50, 50]); // "YES"
tickets([25, 100]); // "NO"
