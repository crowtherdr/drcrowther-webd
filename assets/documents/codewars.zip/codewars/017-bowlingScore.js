function twoBallFrame(rolls) {
  rolls.shift();
  rolls.shift();
}

function isLastFrame(rolls) {
  if (rolls.length === 3) {
    rolls.pop();
    rolls.pop();
  }
}

var bowlingScore = function(rolls) {
  var score = 0;
  var frameCounter = 0;

  while(rolls.length !== 0) {
    // Check for a strike.
    if (rolls[0] === 10 && rolls.length >= 3) {
      score += rolls[0] + rolls[1] + rolls[2];
      if (frameCounter === 9) {
        isLastFrame(rolls);
      }
      rolls.shift();
    }
    else {
      // Check for a spare.
      if (rolls.length >= 2 && (rolls[0] + rolls[1]) === 10) {
        score += rolls[0] + rolls[1] + rolls[2];

        isLastFrame(rolls);

        twoBallFrame(rolls);
      }
      else {
        if (rolls.length >= 2 && rolls[0] !== 10) {
          score += rolls[0] + rolls[1];
          twoBallFrame(rolls);
        }
      }
    }

    frameCounter++;
  }
console.log('score ' , score);
  return score;
};

017-bowlingScore([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]); // 0
017-bowlingScore([9,1, 9,1, 9,1, 9,1, 9,1, 9,1, 9,1, 9,1, 9,1, 9,1, 9]); // 190
017-bowlingScore([10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]); // 300
017-bowlingScore([0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 10,1,0]); // 11
017-bowlingScore([0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 10, 1,0]); // 12
017-bowlingScore([1,2, 3,4, 5,5, 3,2, 9,1, 2,3, 4,5, 2,7, 1,9, 1,2]); // 0
