if (!String.prototype.repeat) {
  String.prototype.repeat = function(count) {
    var repeatedString = "";
    for (var i = 0; i < count; i++) {
      repeatedString += this;
    }
    return repeatedString;
  }
}

function diamond(n){
  var n = n || 0;
  var midpoint = (n / 2) + .5;
  var diam = "";
  var diamondChar = "*";

  if (n < 0 || n % 2 === 0) {
    console.log('null ' , null);
    return null;
  }
  else {
    for (var i = 1; i <= n; i++) {
      if (i !== midpoint) {
        if (i < midpoint) {
          diam += " ".repeat(midpoint - i) + diamondChar.repeat(i + (i - 1)) + "\n";
        }
        else {
          diam += " ".repeat(i - midpoint) + diamondChar.repeat(n - (2 * (i - midpoint))) + "\n";
        }
      }
      else {
        diam += diamondChar.repeat(n) + "\n";
      }
    }
// console.log("middle of odd number: ", n, ":", midpoint);
console.log(diam);
    return diam;
  }
}

diamond(5); // "  *\n ***\n*****\n ***\n  *\n";
diamond(3); // " *\n***\n *\n";
diamond(7);
diamond(9);
diamond(11);
diamond(13);
diamond(15);
diamond(2); // null;
diamond(-3); // null;
diamond(0); // null;

// origNum 7
// 1 =    *
// 2 =   ***
// 3 =  *****
// 4 = *******
// 5 =  *****
// 6 =   ***
// 7 =    *
